import React, { Component } from 'react';
import './Recipes.scss';

class Recipes extends Component {
    render() {
        return (
            <div>
                THis is recipes page
            </div>
        );
    }
}

export default Recipes;